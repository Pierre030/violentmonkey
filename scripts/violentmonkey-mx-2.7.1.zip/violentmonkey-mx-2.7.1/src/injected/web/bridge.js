import { noop } from './helpers';

export default {
  load: noop,
  checkLoad: noop,
};
