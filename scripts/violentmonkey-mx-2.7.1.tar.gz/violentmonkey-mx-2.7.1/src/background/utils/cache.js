import initCache from 'src/common/cache';

export default initCache({
  lifetime: 10 * 1000,
});
